# 宠崽事务所 - 宠物学校小程序（Mock 演示版）

软萌浅色宠物风格微信小程序，覆盖训练托管、接送、寄养、美容洗护、商城、养宠社区、健康档案全部页面。所有数据均为本地 Mock，不依赖数据库与后端。

## 使用方式

1. 打开微信开发者工具，选择“导入项目”。
2. 目录选择本项目根目录（`D:\chongzai-shiwusuo` 或本文件所在目录）。
3. 使用项目内已有的 AppID `wx9f4ab907107350f0`（模拟环境可继续使用）。
4. 编译后从首页进入，所有按钮、表单、弹窗均可点击和输入。

## 完整项目目录结构

```text
chongzai-shiwusuo/
├─ app.js                 # 小程序入口，初始化 Mock 本地数据
├─ app.json               # 页面注册、底部 5 个 Tab 与全局窗口
├─ app.wxss               # 全局软萌配色与通用组件样式
├─ sitemap.json           # 页面索引配置
├─ project.config.json    # 微信开发者工具项目配置
├─ project.private.config.json
├─ README.md
├─ assets/
│  └─ tab/                # 底部导航本地 PNG 图标
│     ├─ home.png / home-on.png
│     ├─ services.png / services-on.png
│     ├─ mall.png / mall-on.png
│     ├─ community.png / community-on.png
│     └─ profile.png / profile-on.png
├─ utils/
│  ├─ mock.js             # 所有 Mock 数据：课程、商品、笔记、档案、订单等
│  ├─ store.js            # 本地缓存仓库：购物车、订单、宠物、社区交互
│  └─ util.js             # 通用工具（微信模板遗留）
└─ pages/
   ├─ home/               # 首页
   │  ├─ home.js
   │  ├─ home.json
   │  ├─ home.wxml
   │  └─ home.wxss
   ├─ services/           # 服务：训练、接送、寄养、美容
   │  ├─ services.js
   │  ├─ services.json
   │  ├─ services.wxml
   │  └─ services.wxss
   ├─ mall/               # 宠崽商城
   │  ├─ mall.js
   │  ├─ mall.json
   │  ├─ mall.wxml
   │  └─ mall.wxss
   ├─ community/          # 养宠社区广场
   │  ├─ community.js
   │  ├─ community.json
   │  ├─ community.wxml
   │  └─ community.wxss
   ├─ profile/            # 个人中心
   │  ├─ profile.js
   │  ├─ profile.json
   │  ├─ profile.wxml
   │  └─ profile.wxss
   ├─ course/             # 训练课程详情
   │  ├─ course.js
   │  ├─ course.json
   │  ├─ course.wxml
   │  └─ course.wxss
   ├─ dynamics/           # 宠崽在校动态
   │  ├─ dynamics.js
   │  ├─ dynamics.json
   │  ├─ dynamics.wxml
   │  └─ dynamics.wxss
   ├─ booking/            # 训练/接送/寄养/美容统一预约表单
   │  ├─ booking.js
   │  ├─ booking.json
   │  ├─ booking.wxml
   │  └─ booking.wxss
   ├─ product/            # 商品详情
   │  ├─ product.js
   │  ├─ product.json
   │  ├─ product.wxml
   │  └─ product.wxss
   ├─ cart/               # 购物车
   │  ├─ cart.js
   │  ├─ cart.json
   │  ├─ cart.wxml
   │  └─ cart.wxss
   ├─ checkout/           # 模拟下单结算
   │  ├─ checkout.js
   │  ├─ checkout.json
   │  ├─ checkout.wxml
   │  └─ checkout.wxss
   ├─ orders/             # 我的订单
   │  ├─ orders.js
   │  ├─ orders.json
   │  ├─ orders.wxml
   │  └─ orders.wxss
   ├─ note-edit/          # 发布养宠日记
   │  ├─ note-edit.js
   │  ├─ note-edit.json
   │  ├─ note-edit.wxml
   │  └─ note-edit.wxss
   ├─ note-detail/        # 笔记详情与评论
   │  ├─ note-detail.js
   │  ├─ note-detail.json
   │  ├─ note-detail.wxml
   │  └─ note-detail.wxss
   ├─ pet/                # 宠物档案列表与录入
   │  ├─ pet.js
   │  ├─ pet.json
   │  ├─ pet.wxml
   │  └─ pet.wxss
   ├─ pet-detail/         # 疫苗、驱虫、成长时间线
   │  ├─ pet-detail.js
   │  ├─ pet-detail.json
   │  ├─ pet-detail.wxml
   │  └─ pet-detail.wxss
   ├─ my-notes/           # 我的养宠日记
   │  ├─ my-notes.js
   │  ├─ my-notes.json
   │  ├─ my-notes.wxml
   │  └─ my-notes.wxss
   ├─ coupons/            # 优惠券
   │  ├─ coupons.js
   │  ├─ coupons.json
   │  ├─ coupons.wxml
   │  └─ coupons.wxss
   ├─ messages/           # 消息通知
   │  ├─ messages.js
   │  ├─ messages.json
   │  ├─ messages.wxml
   │  └─ messages.wxss
   ├─ help/               # 帮助中心
   │  ├─ help.js
   │  ├─ help.json
   │  ├─ help.wxml
   │  └─ help.wxss
   ├─ qa/                 # 养宠问答
   │  ├─ qa.js
   │  ├─ qa.json
   │  ├─ qa.wxml
   │  └─ qa.wxss
   └─ activity/           # 线下活动报名
      ├─ activity.js
      ├─ activity.json
      ├─ activity.wxml
      └─ activity.wxss
```

## 已覆盖功能

- 首页：轮播 Banner、六大快捷入口、课程推荐、爆款商品、热门笔记。
- 服务页：训练套餐、教练名片、学员案例、接送/寄养/美容快捷预约。
- 宠崽在校动态：照片占位、短视频占位、老师训练评语。
- 商城：分类、搜索、商品详情、购物车、学员 Mock 优惠、下单结算。
- 社区：公开/仅自己可见笔记、点赞、评论、收藏、问答、线下活动报名。
- 档案：多宠录入、编辑、疫苗、驱虫、成长时间线。
- 我的：订单分类、我的日记、优惠券、消息、帮助中心。
