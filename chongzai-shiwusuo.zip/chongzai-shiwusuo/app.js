// 宠崽事务所小程序入口
const store = require('./utils/store.js')

App({
  // 启动时写入一次 Mock 种子数据，方便直接演示
  onLaunch() {
    store.initSeed()
  },
  globalData: {
    // 模拟当前登录的学员
    user: {
      name: '栗子妈妈',
      avatar: '👩',
      phone: '138****6086',
      memberTitle: '奶糕学员'
    }
  }
})
