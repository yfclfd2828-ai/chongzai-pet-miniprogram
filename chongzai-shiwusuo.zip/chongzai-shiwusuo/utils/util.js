// 通用工具函数：当前版本主要使用 Mock 数据，保留此文件便于后续扩展

module.exports = {
  // 简单字符串补零，供日志等展示使用
  pad(n) {
    return String(n).padStart(2, '0')
  }
}
