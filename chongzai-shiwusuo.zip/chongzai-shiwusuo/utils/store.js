// 本地 Mock 数据仓库：购物车、订单、档案、社区笔记等全部保存在本地缓存
const mock = require('./mock.js')

const KEY = 'cz_pet_agency_store_v1'
const clone = (value) => JSON.parse(JSON.stringify(value))

// 首次打开小程序时写入种子数据
function initSeed() {
  const existed = wx.getStorageSync(KEY)
  if (existed && existed.version === 1) return
  wx.setStorageSync(KEY, {
    version: 1,
    cart: [],
    orders: clone(mock.seedOrders),
    pets: clone(mock.pets),
    notes: clone(mock.seedNotes),
    coupons: clone(mock.coupons),
    messages: clone(mock.messages),
    activitySignups: [],
    checkedCartCount: 0
  })
}

function getStore() {
  return wx.getStorageSync(KEY) || {}
}

function setStore(store) {
  wx.setStorageSync(KEY, store)
}

function makeId(prefix) {
  const stamp = String(Date.now()).slice(-8)
  const rand = String(Math.floor(Math.random() * 90) + 10)
  return prefix + stamp + rand
}

// 购物车
function getCart() {
  return (getStore().cart || []).map((item, index) => ({ ...item, cartIndex: index }))
}

function setCart(cart) {
  const store = getStore()
  store.cart = cart
  setStore(store)
}

// 加入购物车，相同商品与规格自动合并数量
function addToCart(product, spec, qty) {
  const cart = getStore().cart || []
  const hit = cart.find((item) => item.productId === product.id && item.spec === spec)
  if (hit) {
    hit.qty = (hit.qty || 1) + qty
  } else {
    cart.push({
      productId: product.id,
      name: product.name,
      emoji: product.emoji,
      tone: product.tone,
      price: product.price,
      spec,
      qty,
      checked: true
    })
  }
  setCart(cart)
}

function updateCart(index, patch) {
  const cart = getStore().cart || []
  if (!cart[index]) return
  cart[index] = { ...cart[index], ...patch }
  setCart(cart)
}

function removeCartItem(index) {
  const cart = getStore().cart || []
  cart.splice(index, 1)
  setCart(cart)
}

function clearCheckedCart() {
  const cart = (getStore().cart || []).filter((item) => !item.checked)
  setCart(cart)
}

// 订单
function getOrders() {
  return getStore().orders || []
}

function createOrder(payload) {
  const orders = getOrders()
  const now = new Date()
  const pad = (n) => String(n).padStart(2, '0')
  const no = 'CZ' + now.getFullYear() + pad(now.getMonth() + 1) + pad(now.getDate()) + String(orders.length + 1).padStart(4, '0')
  const order = {
    id: no,
    date: `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`,
    status: 'paid',
    statusText: payload.statusText || '待确认',
    ...payload
  }
  orders.unshift(order)
  const store = getStore()
  store.orders = orders
  setStore(store)
  return order
}

function updateOrder(id, patch) {
  const store = getStore()
  const target = (store.orders || []).find((item) => item.id === id)
  if (target) {
    Object.assign(target, patch)
    setStore(store)
  }
  return target
}

function removeOrder(id) {
  const store = getStore()
  store.orders = (store.orders || []).filter((item) => item.id !== id)
  setStore(store)
}

// 宠物档案
function getPets() {
  return getStore().pets || []
}

function savePet(pet, isNew) {
  const store = getStore()
  const list = store.pets || []
  if (isNew) {
    list.unshift(pet)
  } else {
    const index = list.findIndex((item) => item.id === pet.id)
    if (index > -1) list[index] = pet
  }
  store.pets = list
  setStore(store)
}

function removePet(id) {
  const store = getStore()
  store.pets = (store.pets || []).filter((item) => item.id !== id)
  setStore(store)
}

// 社区笔记
function getNotes() {
  return getStore().notes || []
}

function addNote(data) {
  const store = getStore()
  const note = {
    id: makeId('note-'),
    author: '栗子妈妈',
    emoji: '👩',
    time: '刚刚',
    likes: 0,
    comments: 0,
    collects: 0,
    liked: false,
    collected: false,
    mine: true,
    tone: 'peach-bg',
    ...data
  }
  store.notes = [note, ...(store.notes || [])]
  setStore(store)
  return note
}

function updateNote(id, patch) {
  const store = getStore()
  const note = (store.notes || []).find((item) => item.id === id)
  if (note) {
    Object.assign(note, patch)
    setStore(store)
  }
  return note
}

function removeNote(id) {
  const store = getStore()
  store.notes = (store.notes || []).filter((item) => item.id !== id)
  setStore(store)
}

function toggleNoteField(id, field) {
  const note = updateNote(id, {})
  if (!note) return note
  if (field === 'liked') {
    return updateNote(id, { liked: !note.liked, likes: Math.max(0, (note.likes || 0) + (note.liked ? -1 : 1)) })
  }
  return updateNote(id, { collected: !note.collected, collects: Math.max(0, (note.collects || 0) + (note.collected ? -1 : 1)) })
}

function addCommentToNote(id) {
  const note = updateNote(id, {})
  if (!note) return
  updateNote(id, { comments: (note.comments || 0) + 1 })
}

// 优惠券
function getCoupons() {
  return getStore().coupons || []
}

function setCoupons(coupons) {
  const store = getStore()
  store.coupons = coupons
  setStore(store)
}

// 消息通知
function getMessages() {
  return getStore().messages || []
}

function markMessageRead(id) {
  const store = getStore()
  const msg = (store.messages || []).find((item) => item.id === id)
  if (msg) {
    msg.read = true
    setStore(store)
  }
}

function pushMessage(message) {
  const store = getStore()
  store.messages = [{ read: false, ...message }, ...(store.messages || [])]
  setStore(store)
}

// 活动报名
function getActivitySignups() {
  return getStore().activitySignups || []
}

function signActivity(id) {
  const store = getStore()
  const list = store.activitySignups || []
  if (!list.includes(id)) list.push(id)
  store.activitySignups = list
  setStore(store)
}

function cancelActivity(id) {
  const store = getStore()
  store.activitySignups = (store.activitySignups || []).filter((item) => item !== id)
  setStore(store)
}

// 个人中心统计数据
function getProfileStats() {
  const store = getStore()
  return {
    petCount: (store.pets || []).length,
    noteCount: (store.notes || []).filter((note) => note.mine).length,
    orderCount: (store.orders || []).length,
    couponCount: (store.coupons || []).filter((item) => item.status === 'available').length
  }
}

module.exports = {
  initSeed,
  getCart,
  setCart,
  addToCart,
  updateCart,
  removeCartItem,
  clearCheckedCart,
  getOrders,
  createOrder,
  updateOrder,
  removeOrder,
  getPets,
  savePet,
  removePet,
  getNotes,
  addNote,
  updateNote,
  removeNote,
  toggleNoteField,
  addCommentToNote,
  getCoupons,
  setCoupons,
  getMessages,
  markMessageRead,
  pushMessage,
  getActivitySignups,
  signActivity,
  cancelActivity,
  getProfileStats,
  makeId
}
