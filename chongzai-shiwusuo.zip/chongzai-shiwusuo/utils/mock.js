// 宠崽事务所 Mock 数据源：所有演示内容都在这里维护，无后端依赖

// 首页轮播内容
const banners = [
  {
    id: 'bn-1',
    title: '幼犬开学季',
    sub: '日托训练 8 折体验',
    emoji: '🐶',
    tone: 'peach-bg',
    tag: '开学礼'
  },
  {
    id: 'bn-2',
    title: '上下学接送',
    sub: '早送晚接 老师全程陪护',
    emoji: '🚌',
    tone: 'mint-bg',
    tag: '安心接送'
  },
  {
    id: 'bn-3',
    title: '美容洗护日',
    sub: '香香澡 + 萌新小造型',
    emoji: '🧴',
    tone: 'butter-bg',
    tag: '限时尝鲜'
  }
]

// 首页公告
const notices = [
  '今日 15:00 幼犬社交课还有 2 个名额',
  '接送服务支持自定义早送 / 晚接时段',
  '新学员到校后可免费领取训练小地图'
]

// 首页六大快捷入口
const quickEntries = [
  { id: 'training', title: '预约训练', icon: '🎓', color: '#FFE4D2' },
  { id: 'shuttle', title: '宠物接送', icon: '🚌', color: '#DDF2E8' },
  { id: 'boarding', title: '寄养服务', icon: '🏡', color: '#FFF0C2' },
  { id: 'grooming', title: '美容洗护', icon: '🧴', color: '#F2E8FB' },
  { id: 'mall', title: '宠崽商城', icon: '🛍️', color: '#FFE1E5' },
  { id: 'community', title: '养宠社区', icon: '💬', color: '#E0EFFB' }
]

// 训练套餐
const courses = [
  {
    id: 'course-day',
    name: '日托训练',
    subtitle: '白天入学，放学接回',
    emoji: '🎒',
    tone: 'peach-bg',
    price: 198,
    originalPrice: 268,
    unit: '天',
    sold: 168,
    rating: '4.9',
    target: '适合工作日无人陪伴、希望顺带完成基础训练的宝贝',
    features: ['基础服从', '社会化游戏', '午休加餐', '在校日报'],
    schedule: '08:30 - 18:30',
    desc: '宝贝白天在事务所接受训练托管，傍晚由家长接回。每日包含两节训练课、充足社交游戏和午休，老师会同步文字与照片反馈。'
  },
  {
    id: 'course-board',
    name: '全托寄宿训练',
    subtitle: '住校特训，结业汇报',
    emoji: '🏫',
    tone: 'mint-bg',
    price: 268,
    originalPrice: 368,
    unit: '天',
    sold: 126,
    rating: '4.9',
    target: '适合出差或长假期间希望完成集中训练的狗狗',
    features: ['24小时照护', '每日两训', '一对一视频', '结业课'],
    schedule: '住校 7/14/21/30 天可选',
    desc: '全托寄宿训练把照料和课程融合在一起，训练师每天固定时间进行一对一教学，晚上会有安抚陪伴，每天向家长发送视频小结。'
  },
  {
    id: 'course-social',
    name: '幼犬社会化',
    subtitle: '4-8 月龄黄金期课程',
    emoji: '🐾',
    tone: 'butter-bg',
    price: 128,
    originalPrice: 158,
    unit: '节',
    sold: 212,
    rating: '5.0',
    target: '适合害怕陌生环境、爱扑人、社交紧张的幼犬',
    features: ['脱敏练习', '友好互动', '家长课', '行为评测'],
    schedule: '每周三/周六小班',
    desc: '用游戏化方式帮助幼犬认识更多人类朋友和狗狗伙伴，减少胆怯、吠叫与乱咬，课程结束后提供家庭练习清单。'
  },
  {
    id: 'course-fix',
    name: '行为矫正',
    subtitle: '定制方案，改善坏习惯',
    emoji: '🩹',
    tone: 'rose-bg',
    price: 398,
    originalPrice: 498,
    unit: '次',
    sold: 89,
    rating: '4.8',
    target: '适合有护食、分离焦虑、爆冲、乱叫等行为困扰的宠物',
    features: ['上门评估', '定制方案', '家长陪同', '90天回访'],
    schedule: '每次 90 分钟',
    desc: '先由资深训练师评估行为成因，再设计以正向奖励为核心的矫正方案，家长同步参与学习，帮助宝贝把好习惯带回家。'
  }
]

// 接送、寄养、美容等生活服务
const lifeServices = [
  {
    type: 'shuttle',
    title: '宠物上下学接送',
    emoji: '🚌',
    tone: 'mint-bg',
    unit: '次',
    price: 39,
    desc: '上学顺风车与放学护送，司机和随车老师双人确认，全程宠物箱接送。',
    points: ['上门接宠', '宠物箱固定', '实时出发通知', '安全签收']
  },
  {
    type: 'boarding',
    title: '短期寄养',
    emoji: '🏡',
    tone: 'butter-bg',
    unit: '晚',
    price: 168,
    desc: '独立寄养间 + 每日遛放 + 睡前安抚，节假日热门档期建议提前预约。',
    points: ['独立睡眠间', '每日两次遛放', '每日照片', '陪伴安抚']
  },
  {
    type: 'grooming',
    title: '美容洗护',
    emoji: '🧴',
    tone: 'lilac-bg',
    unit: '次',
    price: 128,
    desc: '温和低敏洗护、指甲修剪、耳道清洁、屁屁毛修剪，可选可爱造型。',
    points: ['低敏香波', '全套基础护理', '造型可选', '皮肤检查']
  }
]

// 教练介绍
const coaches = [
  {
    id: 'coach-1',
    name: '米粒老师',
    emoji: '🐕',
    badge: '犬行为学认证',
    years: '7 年',
    tags: ['幼犬社会化', '分离焦虑'],
    intro: '擅长用游戏建立信任，学员家长称她为“狗狗嘴替”。',
    students: 420
  },
  {
    id: 'coach-2',
    name: '大福教练',
    emoji: '🐩',
    badge: '服务犬训练师',
    years: '9 年',
    tags: ['随行训练', '全托特训'],
    intro: '前服务犬训练基地主训，专注稳定、安静、可跟随的生活技能。',
    students: 318
  },
  {
    id: 'coach-3',
    name: '橙子老师',
    emoji: '🐈',
    badge: '猫咪行为顾问',
    years: '5 年',
    tags: ['猫咪社交', '环境丰容'],
    intro: '猫咪和胆小狗狗都愿意靠近的老师，全程低压力操作。',
    students: 176
  }
]

// 学员案例
const cases = [
  {
    id: 'case-1',
    title: '爆冲柴犬变稳重',
    pet: '柴犬·年糕',
    emoji: '🐶',
    issue: '出门爆冲、见狗就喊',
    plan: '12 天全托寄宿训练',
    result: '可松绳跟走 30 米，见到同类不再扑冲',
    teacher: '大福教练',
    week: 2
  },
  {
    id: 'case-2',
    title: '黏人布偶学会独处',
    pet: '布偶猫·奶盖',
    emoji: '🐱',
    issue: '家长出门就嚎叫',
    plan: '4 次上门行为矫正',
    result: '独处 4 小时情绪平稳，能自己玩玩具',
    teacher: '橙子老师',
    week: 3
  },
  {
    id: 'case-3',
    title: '胆小狗爱上幼儿园',
    pet: '泰迪·团子',
    emoji: '🐻',
    issue: '不敢靠近陌生人',
    plan: '幼犬社会化 6 节小班课',
    result: '主动闻嗅陌生朋友，还能玩轮流游戏',
    teacher: '米粒老师',
    week: 4
  }
]

// 在校动态：照片 / 短视频占位内容
const moments = [
  {
    id: 'm-1',
    pet: '布丁',
    petEmoji: '🐶',
    time: '今天 10:32',
    title: '等待训练完成，奖励来啦',
    note: '布丁今天完成 4 次 10 秒等待，奖励时尾巴都快摇成小风扇啦。',
    teacher: '米粒老师',
    tone: 'peach-bg',
    emoji: '🍪',
    type: 'photo',
    likes: 32
  },
  {
    id: 'm-2',
    pet: '雪球',
    petEmoji: '🐱',
    time: '今天 09:15',
    title: '晨间丰容小挑战',
    note: '雪球用嗅闻垫找到三颗冻干，认真工作的样子超萌。',
    teacher: '橙子老师',
    tone: 'lilac-bg',
    emoji: '🧶',
    type: 'video',
    likes: 27
  },
  {
    id: 'm-3',
    pet: '布丁',
    petEmoji: '🐶',
    time: '昨天 16:40',
    title: '和同学玩拔河',
    note: '学会了“给”，松开玩具后立刻得到小饼干，社交氛围棒棒。',
    teacher: '米粒老师',
    tone: 'mint-bg',
    emoji: '🧸',
    type: 'photo',
    likes: 19
  }
]

// 商品分类
const productCategories = [
  { id: 'all', name: '全部' },
  { id: 'food', name: '主粮零食' },
  { id: 'clothes', name: '宠物服饰' },
  { id: 'daily', name: '日用好物' },
  { id: 'care', name: '洗护用品' },
  { id: 'training', name: '训练道具' }
]

// 商城商品
const products = [
  { id: 'p-1', name: '元气鲜肉全价主粮 2kg', cat: 'food', emoji: '🍖', tone: 'peach-bg', price: 138, originPrice: 168, tag: '学员立减20', sales: 520, spec: ['2kg 装', '4kg 装'], tip: '下单备注宝贝体重可获喂食建议' },
  { id: 'p-2', name: '三文鱼鸡肉冻干桶', cat: 'food', emoji: '🐟', tone: 'rose-bg', price: 89, originPrice: 109, tag: '训练奖励', sales: 328, spec: ['300g', '500g'], tip: '适合训练奖励，小颗粒不粘手' },
  { id: 'p-3', name: '奶香无糖宠物羊奶', cat: 'food', emoji: '🥛', tone: 'butter-bg', price: 29.9, originPrice: 39.9, tag: '回购王', sales: 861, spec: ['1L'], tip: '开封后冷藏，3 天内饮用' },
  { id: 'p-4', name: '日式渔夫帽宠物小外套', cat: 'clothes', emoji: '🧥', tone: 'mint-bg', price: 79, originPrice: 99, tag: '上新', sales: 96, spec: ['S 号', 'M 号', 'L 号'], tip: '棉麻面料，适合春秋遛弯' },
  { id: 'p-5', name: '狗狗生日小披风', cat: 'clothes', emoji: '🎂', tone: 'rose-bg', price: 69, originPrice: 88, tag: '聚会款', sales: 152, spec: ['均码'], tip: '生日、结业礼都很好拍' },
  { id: 'p-6', name: '宠物随行水杯 500ml', cat: 'daily', emoji: '🥤', tone: 'peach-bg', price: 59, originPrice: 79, tag: '户外必备', sales: 437, spec: ['奶橘', '薄荷', '奶油白'], tip: '按压出水，单手可操作' },
  { id: 'p-7', name: '柔软慢食碗', cat: 'daily', emoji: '🍚', tone: 'butter-bg', price: 45, originPrice: 62, tag: '防呛', sales: 289, spec: ['小号', '中号'], tip: '帮助宝贝放慢干饭速度' },
  { id: 'p-8', name: '低敏燕麦香波 500ml', cat: 'care', emoji: '🧴', tone: 'lilac-bg', price: 98, originPrice: 128, tag: '美容师同款', sales: 204, spec: ['犬用', '猫用'], tip: '温和清洁，洗后毛很蓬松' },
  { id: 'p-9', name: '宠物指甲剪 + 锉刀套装', cat: 'care', emoji: '✂️', tone: 'mint-bg', price: 39, originPrice: 55, tag: '新手友好', sales: 341, spec: ['一套'], tip: '有安全挡片，避免剪到血线' },
  { id: 'p-10', name: '响片训练器', cat: 'training', emoji: '🔔', tone: 'butter-bg', price: 25, originPrice: 35, tag: '训练师推荐', sales: 623, spec: ['响片+哨'], tip: '配合零食点击标记正确行为' },
  { id: 'p-11', name: '嗅闻游戏垫', cat: 'training', emoji: '🧩', tone: 'mint-bg', price: 72, originPrice: 96, tag: '益智消遣', sales: 190, spec: ['小号', '大号'], tip: '可机洗，隐藏零食激发探索' },
  { id: 'p-12', name: '慢速牵引绳', cat: 'training', emoji: '🦮', tone: 'lilac-bg', price: 119, originPrice: 149, tag: '防爆冲', sales: 116, spec: ['1.2m', '2.0m'], tip: '双把手设计，训练随行更好用' }
]

// 养宠日记种子笔记
const seedNotes = [
  {
    id: 'n-1',
    title: '布丁第一次学会等待，全家感动',
    content: '早上打开教室门，布丁居然安静地坐好等我放饭，那一刻真的觉得上学没白上。老师提醒我们要在家里也做 5 次小练习，狗狗的稳定都是一点点攒出来的。',
    author: '栗子妈妈',
    emoji: '🐶',
    time: '2 小时前',
    tag: '训练日记',
    likes: 68,
    comments: 12,
    collects: 9,
    public: true,
    mine: true,
    liked: false,
    collected: false,
    tone: 'peach-bg'
  },
  {
    id: 'n-2',
    title: '猫咪寄养回来居然变黏人',
    content: '出差 5 天把雪球送去事务所寄养，每天都收到照片和视频。回来以后它不仅没有生气，还主动蹭我，看来橙子老师的睡前安抚很有效。',
    author: '雪球姐姐',
    emoji: '🐱',
    time: '昨天 20:16',
    tag: '寄养日记',
    likes: 124,
    comments: 31,
    collects: 18,
    public: true,
    mine: false,
    liked: false,
    collected: false,
    tone: 'lilac-bg'
  },
  {
    id: 'n-3',
    title: '接送服务拯救了我的早高峰',
    content: '以前每天先送狗再去公司，上班总迟到。现在下单接送后，师傅 8 点 10 分到楼下，路上还会发视频给我看宝贝在宠物箱里睡觉，太安心啦。',
    author: '年糕妈妈',
    emoji: '🚌',
    time: '周一 09:05',
    tag: '接送日记',
    likes: 203,
    comments: 45,
    collects: 32,
    public: true,
    mine: false,
    liked: false,
    collected: false,
    tone: 'mint-bg'
  },
  {
    id: 'n-4',
    title: '自己在家做嗅闻游戏',
    content: '下雨天不能出门，就把冻干藏在旧毛巾和纸箱里。团子找了 15 分钟，结束后很快就睡着了，嗅闻真的是最好的室内消耗。',
    author: '团子爸',
    emoji: '🐻',
    time: '8 月 28 日',
    tag: '养宠好物',
    likes: 87,
    comments: 17,
    collects: 41,
    public: true,
    mine: false,
    liked: false,
    collected: false,
    tone: 'butter-bg'
  },
  {
    id: 'n-5',
    title: '美容前后对比太治愈',
    content: '毛孩美容完像换了一只狗！老师还帮它剪了指甲、掏了耳朵，回家路上一直很兴奋。以后每个月都要预约一次洗护。',
    author: '布丁妈',
    emoji: '🧴',
    time: '8 月 25 日',
    tag: '洗护日记',
    likes: 156,
    comments: 22,
    collects: 15,
    public: false,
    mine: false,
    liked: false,
    collected: false,
    tone: 'rose-bg'
  }
]

// 社区问答
const qaList = [
  {
    id: 'q-1',
    question: '幼犬到家多久可以开始社会化课？',
    answer: '完成基础疫苗并观察一周后就可以。老师会先做评估，胆小宝贝可以从“看课”开始，不必强迫互动。',
    category: '幼犬养育',
    votes: 35,
    time: '今天'
  },
  {
    id: 'q-2',
    question: '寄养需要带哪些东西？',
    answer: '建议带常吃的粮、平时玩具、一件有家长气味的旧衣服，以及驱虫记录。床垫和水碗事务所会准备。',
    category: '寄养',
    votes: 21,
    time: '昨天'
  },
  {
    id: 'q-3',
    question: '猫咪多久洗一次澡合适？',
    answer: '健康猫咪一般 2-3 个月洗一次即可，日常可以靠梳毛和湿巾清洁。洗澡请选择猫咪专用低敏产品。',
    category: '美容洗护',
    votes: 18,
    time: '3 天前'
  }
]

// 线下活动
const activities = [
  {
    id: 'act-1',
    name: '秋日狗狗运动会',
    emoji: '🏅',
    tone: 'peach-bg',
    time: '09月20日 14:00',
    place: '事务所草坪校区',
    limit: '限 20 只',
    desc: '小短跑、穿越隧道、家长指令挑战，完赛就有零食大礼包。',
    tag: '本周活动'
  },
  {
    id: 'act-2',
    name: '猫咪丰容工作坊',
    emoji: '🧶',
    tone: 'lilac-bg',
    time: '09月27日 10:30',
    place: '事务所咖啡馆',
    limit: '限 12 组',
    desc: '现场制作嗅闻垫，学习判断猫咪压力信号，带走一套材料包。',
    tag: '亲子同行'
  },
  {
    id: 'act-3',
    name: '遛狗礼仪公开课',
    emoji: '🦮',
    tone: 'mint-bg',
    time: '10月11日 09:30',
    place: '滨江宠物步道',
    limit: '限 25 只',
    desc: '练习随行、避让和社交，免费参加，适合新手家长。',
    tag: '免费'
  }
]

// 优惠券
const coupons = [
  { id: 'coupon-1', title: '训练新客立减券', condition: '满 500 元可用', price: 80, kind: 'training', end: '2026-09-30', status: 'available', icon: '🎓' },
  { id: 'coupon-2', title: '接送体验券', condition: '满 5 次可用', price: 30, kind: 'shuttle', end: '2026-10-15', status: 'available', icon: '🚌' },
  { id: 'coupon-3', title: '寄养暖心券', condition: '满 3 晚可用', price: 100, kind: 'boarding', end: '2026-10-31', status: 'available', icon: '🏡' },
  { id: 'coupon-4', title: '商城 9.5 折券', condition: '全场可用', price: 0, kind: 'mall', end: '2026-11-30', status: 'available', icon: '🛍️' },
  { id: 'coupon-5', title: '早鸟接送券', condition: '满 5 次可用', price: 20, kind: 'shuttle', end: '2026-09-02', status: 'used', icon: '🚌' },
  { id: 'coupon-6', title: '夏日洗澡券', condition: '洗护满 200 元可用', price: 30, kind: 'grooming', end: '2026-08-15', status: 'expired', icon: '🧴' }
]

// 消息通知
const messages = [
  {
    id: 'msg-1',
    type: 'order',
    title: '布丁今日训练已完成',
    content: '老师已上传今日照片 6 张，布丁学会 10 秒等待，记得查看在校动态哦。',
    time: '今天 11:02',
    read: false
  },
  {
    id: 'msg-2',
    type: 'activity',
    title: '秋日运动会开始报名',
    content: '活动限 20 只狗狗，名额以报名成功页为准，报名后可在活动页查看。',
    time: '今天 09:00',
    read: false
  },
  {
    id: 'msg-3',
    type: 'order',
    title: '接送车辆已出发',
    content: '预计 08:25 到达你家楼下，司机：刘师傅，尾号 618。',
    time: '昨天 08:03',
    read: true
  }
]

// 宠物健康档案默认数据
const pets = [
  {
    id: 'pet-1',
    name: '布丁',
    avatar: '🐶',
    species: '犬',
    breed: '柴犬',
    gender: '妹妹',
    birthday: '2025-03-12',
    age: '1 岁 5 个月',
    weight: '9.6kg',
    color: '奶橘',
    microchip: 'CN20250312001',
    allergy: '暂未发现',
    vaccine: [
      { name: '犬八联疫苗（第三针）', date: '2026-08-02', next: '2027-08-02', done: true },
      { name: '狂犬疫苗', date: '2026-05-18', next: '2027-05-18', done: true }
    ],
    deworm: [
      { name: '体内驱虫', date: '2026-09-01', next: '2026-11-01', done: true },
      { name: '体外驱虫', date: '2026-08-18', next: '2026-09-18', done: true }
    ],
    timeline: [
      { date: '2026-09-06', title: '学会等待 10 秒', note: '今天训练课进步很大，家里也可以开始练习。' },
      { date: '2026-08-02', title: '完成疫苗加强', note: '接种后精神良好，体重 9.4kg。' },
      { date: '2026-07-01', title: '第一次到事务所', note: '评估日：外向活泼，有些激动扑人。' }
    ]
  },
  {
    id: 'pet-2',
    name: '雪球',
    avatar: '🐱',
    species: '猫',
    breed: '布偶猫',
    gender: '弟弟',
    birthday: '2025-11-06',
    age: '10 个月',
    weight: '4.8kg',
    color: '海双',
    microchip: 'CN20251106002',
    allergy: '暂未发现',
    vaccine: [
      { name: '猫三联疫苗（第三针）', date: '2026-07-20', next: '2027-07-20', done: true }
    ],
    deworm: [
      { name: '体内外同驱', date: '2026-09-01', next: '2026-10-01', done: true }
    ],
    timeline: [
      { date: '2026-09-06', title: '完成晨间丰容', note: '嗅闻垫找冻干 5 分钟，状态放松。' },
      { date: '2026-07-20', title: '完成疫苗加强', note: '雪球在医院很紧张，回家后躲了两小时。' }
    ]
  }
]

// 历史订单（用于“我的订单”初始展示）
const seedOrders = [
  {
    id: 'CZ20260905001',
    type: 'training',
    typeName: '训练托管',
    title: '日托训练 · 7 天',
    pet: '布丁',
    status: 'training',
    statusText: '训练中',
    amount: 1188,
    date: '2026-09-05',
    start: '2026-09-05',
    end: '2026-09-11',
    coach: '米粒老师',
    place: '宠崽事务所 · 朝阳校区',
    desc: '含基础服从、社会化游戏、在校照片日报。',
    emoji: '🎒'
  },
  {
    id: 'CZ20260904002',
    type: 'shuttle',
    typeName: '接送预约',
    title: '上下学接送 · 3 次',
    pet: '布丁',
    status: 'completed',
    statusText: '已完成',
    amount: 99,
    date: '2026-09-04',
    start: '2026-09-05',
    end: '2026-09-07',
    coach: '刘师傅',
    place: '栗子路 88 号',
    desc: '每日 08:20 接、18:10 送，宠物箱接送。',
    emoji: '🚌'
  },
  {
    id: 'CZ20260901003',
    type: 'mall',
    typeName: '商城订单',
    title: '元气鲜肉全价主粮 2kg',
    pet: '布丁',
    status: 'shipped',
    statusText: '已发货',
    amount: 138,
    date: '2026-09-01',
    start: '',
    end: '',
    coach: '',
    place: '栗子路 88 号',
    desc: '数量：1 件，规格：2kg 装。',
    emoji: '🍖'
  },
  {
    id: 'CZ20260828004',
    type: 'grooming',
    typeName: '美容洗护',
    title: '猫咪基础洗护',
    pet: '雪球',
    status: 'paid',
    statusText: '待到店',
    amount: 128,
    date: '2026-08-28',
    start: '2026-09-12 10:30',
    end: '',
    coach: '橙子老师',
    place: '宠崽事务所 · 朝阳校区',
    desc: '低敏洗护、剪指甲、耳道清洁。',
    emoji: '🧴'
  }
]

// 帮助中心常见问题
const helpFaqs = [
  {
    title: '入校需要准备哪些物品？',
    content: '首次入校请带疫苗记录、少量过渡粮和宝贝喜欢的安抚玩具。学校会提供水碗、睡垫和日常清洁用品。'
  },
  {
    title: '宠物上下学接送规则',
    content: '请提前 5 分钟带宝贝在门口等待；接送车辆会使用安全宠物箱，全程由随车老师看护，抵达与离校都会拍照确认。'
  },
  {
    title: '训练课程请假怎么处理？',
    content: '日托与全托课程如需请假，请提前一天在订单页申请，余额会保留到下次使用。当天临时请假会按半日扣减。'
  },
  {
    title: '寄养期间可以视频探望吗？',
    content: '可以。每日 19:00-21:00 可发起视频探望，也可以随时查看老师发送的今日照片与动态。'
  }
]

// 寄养、接送服务规则
const serviceRules = {
  shuttle: ['车辆出发前 10 分钟推送通知', '宠物全程使用安全宠物箱', '抵达后需家长签收确认', '若遇大雨天气会提前沟通调整'],
  boarding: ['入住前需提供近期驱虫与疫苗记录', '短住满 3 晚赠送一次基础洗澡', '每日两次遛放与一次视频探望', '入住期间若生病会第一时间送医并联系家长'],
  grooming: ['洗护全程使用低敏产品', '建议提前 10 分钟到店安抚', '造型项目需在预约时备注', '皮肤有异常会暂停操作并建议就医']
}

module.exports = {
  banners,
  notices,
  quickEntries,
  courses,
  lifeServices,
  coaches,
  cases,
  moments,
  productCategories,
  products,
  seedNotes,
  qaList,
  activities,
  coupons,
  messages,
  pets,
  seedOrders,
  helpFaqs,
  serviceRules
}
