// 商品详情：规格选择、加入购物车、立即购买与相关推荐
const mock = require('../../utils/mock.js')
const store = require('../../utils/store.js')

Page({
  data: {
    product: null,
    specList: [],
    specIndex: 0,
    qty: 1,
    favorite: false,
    related: []
  },

  onLoad(options) {
    const id = options.id || 'p-1'
    const product = mock.products.find((item) => item.id === id) || mock.products[0]
    const related = mock.products.filter((item) => item.id !== product.id).slice(0, 3)
    this.setData({
      product,
      specList: product.spec,
      related
    })
    wx.setNavigationBarTitle({ title: product.name })
  },

  chooseSpec(e) {
    this.setData({ specIndex: Number(e.currentTarget.dataset.index) })
  },

  minus() {
    if (this.data.qty > 1) this.setData({ qty: this.data.qty - 1 })
  },

  plus() {
    if (this.data.qty < 99) this.setData({ qty: this.data.qty + 1 })
  },

  toggleFavorite() {
    this.setData({ favorite: !this.data.favorite })
    wx.showToast({ title: this.data.favorite ? '已加入心愿单' : '已取消收藏', icon: 'none' })
  },

  addCart() {
    store.addToCart(this.data.product, this.data.specList[this.data.specIndex], this.data.qty)
    wx.showToast({ title: '已加入购物车', icon: 'success' })
  },

  buyNow() {
    const p = this.data.product
    const spec = encodeURIComponent(this.data.specList[this.data.specIndex])
    wx.navigateTo({
      url: `/pages/checkout/checkout?direct=1&productId=${p.id}&qty=${this.data.qty}&spec=${spec}`
    })
  },

  goProduct(e) {
    const id = e.currentTarget.dataset.id
    wx.redirectTo({ url: `/pages/product/product?id=${id}` })
  },

  goCart() {
    wx.navigateTo({ url: '/pages/cart/cart' })
  }
})
