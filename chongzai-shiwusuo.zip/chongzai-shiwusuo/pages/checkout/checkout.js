// 结算页：支持购物车结算与商品页直接购买两种 Mock 模式
const mock = require('../../utils/mock.js')
const store = require('../../utils/store.js')

Page({
  data: {
    mode: 'cart',
    items: [],
    addresses: [
      { name: '栗子妈妈', phone: '138****6086', detail: '栗子路 88 号 3 栋 602', tag: '家' },
      { name: '栗子妈妈', phone: '138****6086', detail: '滨江宠物步道 12 号门店', tag: '公司' }
    ],
    addressIndex: 0,
    subtotal: 0,
    studentDiscount: 0,
    couponLabel: '学员 9.5 折',
    couponDiscount: 0,
    total: 0,
    payMethod: 'wechat',
    couponOptions: [
      { id: 'none', name: '不使用优惠券', amount: 0 },
      { id: 'student', name: '在籍学员 9.5 折', amount: 0 },
      { id: 'mall', name: '商城 9.5 折券', amount: 0 }
    ],
    couponIndex: 1,
    successOrder: null
  },

  onLoad(options) {
    let items = []
    let mode = 'cart'
    if (options.direct === '1') {
      mode = 'direct'
      const product = mock.products.find((item) => item.id === options.productId) || mock.products[0]
      items = [{
        productId: product.id,
        name: product.name,
        emoji: product.emoji,
        tone: product.tone,
        spec: decodeURIComponent(options.spec || product.spec[0]),
        qty: Number(options.qty || 1),
        price: product.price
      }]
    } else {
      items = store.getCart().filter((item) => item.checked).map((item) => ({
        productId: item.productId,
        name: item.name,
        emoji: item.emoji,
        tone: item.tone,
        spec: item.spec,
        qty: item.qty,
        price: item.price
      }))
    }
    this.setData({ mode, items }, () => this.calc())
  },

  switchAddress() {
    const next = (this.data.addressIndex + 1) % this.data.addresses.length
    this.setData({ addressIndex: next })
  },

  chooseCoupon(e) {
    this.setData({ couponIndex: Number(e.currentTarget.dataset.index) }, () => this.calc())
  },

  choosePay(e) {
    this.setData({ payMethod: e.currentTarget.dataset.method })
  },

  calc() {
    const subtotal = this.data.items.reduce((sum, item) => sum + item.price * item.qty, 0)
    const studentDiscount = Number((subtotal * 0.05).toFixed(2))
    const couponIndex = this.data.couponIndex
    const couponName = couponIndex === 0 ? '' : (couponIndex === 1 ? '在籍学员 9.5 折' : '商城 9.5 折券')
    const couponDiscount = Number((subtotal * (couponIndex === 0 ? 0 : 0.05)).toFixed(2))
    const total = Number(Math.max(0, subtotal - studentDiscount - couponDiscount).toFixed(2))
    this.setData({
      subtotal: Number(subtotal.toFixed(2)),
      studentDiscount,
      couponLabel: couponName,
      couponDiscount,
      total
    })
  },

  submitOrder() {
    const title = this.data.items.length > 1
      ? `商城订单（${this.data.items.length} 件商品）`
      : this.data.items[0].name
    const desc = this.data.items.map((item) => `${item.name} ×${item.qty}（${item.spec}）`).join('；')
    const address = this.data.addresses[this.data.addressIndex]
    const order = store.createOrder({
      type: 'mall',
      typeName: '商城订单',
      title,
      pet: '',
      status: 'paid',
      statusText: '待发货',
      amount: this.data.total,
      date: '2026-09-06',
      start: '',
      end: '',
      coach: '',
      place: `${address.tag} · ${address.detail}`,
      desc,
      emoji: this.data.items.length === 1 ? this.data.items[0].emoji : '🛍️',
      payMethod: this.data.payMethod === 'wechat' ? '模拟微信支付' : '模拟余额支付'
    })
    if (this.data.mode === 'cart') store.clearCheckedCart()
    store.pushMessage({
      type: 'order',
      title: '商城订单提交成功',
      content: `${order.title} 已进入模拟发货流程。`,
      time: '刚刚'
    })
    this.setData({ successOrder: order })
  },

  closeSuccess() {
    this.setData({ successOrder: null })
  },

  goOrders() {
    this.setData({ successOrder: null })
    wx.redirectTo({ url: '/pages/orders/orders?type=mall' })
  },

  goMall() {
    wx.switchTab({ url: '/pages/mall/mall' })
  }
})
