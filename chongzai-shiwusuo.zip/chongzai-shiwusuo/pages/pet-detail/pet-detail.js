// 宠物健康档案详情：疫苗、驱虫与成长时间线维护
const store = require('../../utils/store.js')

Page({
  data: {
    pet: null,
    showRecordForm: false,
    recordType: 'vaccine',
    recordForm: {
      name: '',
      date: '2026-09-06',
      note: ''
    }
  },

  onLoad(options) {
    this.petId = options.id
    this.loadPet()
  },

  onShow() {
    if (this.petId) this.loadPet()
  },

  loadPet() {
    const pet = store.getPets().find((item) => item.id === this.petId)
    if (!pet) {
      wx.showToast({ title: '档案不存在', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 400)
      return
    }
    this.setData({ pet })
  },

  goEditList() {
    wx.navigateBack()
  },

  addRecord(e) {
    const type = e.currentTarget.dataset.type
    const names = {
      vaccine: '',
      deworm: '',
      timeline: ''
    }
    this.setData({
      showRecordForm: true,
      recordType: type,
      recordForm: {
        name: names[type],
        date: '2026-09-06',
        note: ''
      }
    })
  },

  closeRecordForm() {
    this.setData({ showRecordForm: false })
  },

  onRecordName(e) {
    this.setData({ 'recordForm.name': e.detail.value })
  },

  onRecordNote(e) {
    this.setData({ 'recordForm.note': e.detail.value })
  },

  onRecordDate(e) {
    this.setData({ 'recordForm.date': e.detail.value })
  },

  saveRecord() {
    const form = this.data.recordForm
    const isTimeline = this.data.recordType === 'timeline'
    if (!isTimeline && !form.name.trim()) {
      wx.showToast({ title: '请填写记录名称', icon: 'none' })
      return
    }
    const pet = JSON.parse(JSON.stringify(this.data.pet))
    if (isTimeline) {
      pet.timeline = [{
        date: form.date,
        title: form.note.trim() || form.name.trim() || '成长纪念',
        note: '家长在健康档案中添加的成长备忘'
      }, ...(pet.timeline || [])]
    } else {
      const key = this.data.recordType
      pet[key] = [{
        name: form.name.trim(),
        date: form.date,
        note: form.note,
        done: true
      }, ...(pet[key] || [])]
    }
    store.savePet(pet, false)
    this.setData({ showRecordForm: false, pet })
    wx.showToast({ title: isTimeline ? '时间线已添加' : '健康记录已添加', icon: 'success' })
  },

  deleteRecord(e) {
    const key = e.currentTarget.dataset.key
    const index = Number(e.currentTarget.dataset.index)
    const pet = JSON.parse(JSON.stringify(this.data.pet))
    pet[key].splice(index, 1)
    store.savePet(pet, false)
    this.setData({ pet })
  },

  noop() {}
})
