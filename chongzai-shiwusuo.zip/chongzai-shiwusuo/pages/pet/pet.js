// 宠物档案列表：录入多只宠物、基础信息维护与删除
const store = require('../../utils/store.js')

Page({
  data: {
    pets: [],
    showForm: false,
    isNew: true,
    form: {
      name: '',
      species: '犬',
      breed: '',
      gender: '妹妹',
      birthday: '2025-06-01',
      weight: '',
      color: '',
      allergy: '暂未发现'
    },
    speciesOptions: ['犬', '猫', '兔子', '仓鼠'],
    genderOptions: ['妹妹', '弟弟']
  },

  onShow() {
    this.setData({ pets: store.getPets() })
  },

  goDetail(e) {
    wx.navigateTo({ url: `/pages/pet-detail/pet-detail?id=${e.currentTarget.dataset.id}` })
  },

  addPet() {
    this.setData({
      showForm: true,
      isNew: true,
      form: {
        name: '',
        species: '犬',
        breed: '',
        gender: '妹妹',
        birthday: '2025-06-01',
        weight: '',
        color: '',
        allergy: '暂未发现'
      }
    })
  },

  editPet(e) {
    const pet = this.data.pets.find((item) => item.id === e.currentTarget.dataset.id)
    if (!pet) return
    this.setData({
      showForm: true,
      isNew: false,
      editingId: pet.id,
      form: {
        name: pet.name,
        species: pet.species,
        breed: pet.breed,
        gender: pet.gender,
        birthday: pet.birthday,
        weight: pet.weight.replace('kg', ''),
        color: pet.color,
        allergy: pet.allergy
      }
    })
  },

  closeForm() {
    this.setData({ showForm: false })
  },

  onInput(e) {
    const key = e.currentTarget.dataset.key
    this.setData({ [`form.${key}`]: e.detail.value })
  },

  pickSpecies(e) {
    this.setData({ 'form.species': this.data.speciesOptions[Number(e.detail.value)] })
  },

  pickGender(e) {
    this.setData({ 'form.gender': this.data.genderOptions[Number(e.detail.value)] })
  },

  pickBirthday(e) {
    this.setData({ 'form.birthday': e.detail.value })
  },

  savePet() {
    const f = this.data.form
    if (!f.name || !f.breed || !f.weight) {
      wx.showToast({ title: '姓名、品种和体重必填', icon: 'none' })
      return
    }
    const age = this.calcAge(f.birthday)
    const pet = {
      id: this.data.isNew ? store.makeId('pet-') : this.data.editingId,
      name: f.name,
      avatar: f.species === '猫' ? '🐱' : f.species === '犬' ? '🐶' : f.species === '兔子' ? '🐰' : '🐹',
      species: f.species,
      breed: f.breed,
      gender: f.gender,
      birthday: f.birthday,
      age,
      weight: `${Number(f.weight)}kg`,
      color: f.color || '暂未填写',
      allergy: f.allergy || '暂未发现',
      microchip: this.data.isNew ? `CN2026${String(Date.now()).slice(-6)}` : (this.data.pets.find((p) => p.id === this.data.editingId) || {}).microchip || '',
      vaccine: this.data.isNew ? [] : (this.data.pets.find((p) => p.id === this.data.editingId) || {}).vaccine || [],
      deworm: this.data.isNew ? [] : (this.data.pets.find((p) => p.id === this.data.editingId) || {}).deworm || [],
      timeline: this.data.isNew ? [{
        date: '2026-09-06',
        title: '档案建立',
        note: '欢迎加入宠崽事务所，第一次健康记录已创建。'
      }] : (this.data.pets.find((p) => p.id === this.data.editingId) || {}).timeline || []
    }
    store.savePet(pet, this.data.isNew)
    this.setData({ showForm: false, pets: store.getPets() })
    wx.showToast({ title: this.data.isNew ? '宝贝档案已创建' : '档案已更新', icon: 'success' })
  },

  calcAge(birthday) {
    const diff = Date.now() - new Date(birthday.replace(/-/g, '/')).getTime()
    const months = Math.max(1, Math.floor(diff / (1000 * 60 * 60 * 24 * 30)))
    if (months < 12) return `${months} 个月`
    return `${Math.floor(months / 12)} 岁 ${months % 12} 个月`
  },

  deletePet(e) {
    const id = e.currentTarget.dataset.id
    const pet = this.data.pets.find((item) => item.id === id)
    wx.showModal({
      title: '删除档案',
      content: `确定删除 ${pet ? pet.name : '该宝贝'} 的 Mock 档案吗？`,
      confirmText: '删除',
      success: (res) => {
        if (res.confirm) {
          store.removePet(id)
          this.setData({ pets: store.getPets() })
          wx.showToast({ title: '档案已删除', icon: 'none' })
        }
      }
    })
  },

  noop() {}
})
