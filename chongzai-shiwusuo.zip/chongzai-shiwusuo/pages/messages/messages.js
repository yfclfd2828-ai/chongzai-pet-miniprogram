// 消息通知：订单、动态与活动消息
const store = require('../../utils/store.js')

Page({
  data: {
    filters: [
      { id: 'all', name: '全部' },
      { id: 'order', name: '订单' },
      { id: 'activity', name: '活动' },
      { id: 'school', name: '在校' }
    ],
    activeFilter: 'all',
    messages: [],
    allMessages: [],
    selectedMessage: null
  },

  onShow() {
    this.refresh()
  },

  refresh() {
    const allMessages = store.getMessages()
    const activeFilter = this.data.activeFilter
    const list = activeFilter === 'all' ? allMessages : allMessages.filter((item) => item.type === activeFilter)
    const unread = allMessages.filter((item) => !item.read).length
    this.setData({ allMessages, messages: list, unread })
  },

  switchFilter(e) {
    this.setData({ activeFilter: e.currentTarget.dataset.id }, () => this.refresh())
  },

  openMessage(e) {
    const id = e.currentTarget.dataset.id
    const message = this.data.allMessages.find((item) => item.id === id)
    store.markMessageRead(id)
    this.setData({ selectedMessage: message })
    this.refresh()
  },

  closeMessage() {
    this.setData({ selectedMessage: null })
  },

  goAction() {
    const msg = this.data.selectedMessage
    this.setData({ selectedMessage: null })
    if (msg && msg.type === 'activity') {
      wx.navigateTo({ url: '/pages/activity/activity' })
      return
    }
    wx.navigateTo({ url: '/pages/orders/orders?type=all' })
  },

  readAll() {
    this.data.allMessages.forEach((item) => store.markMessageRead(item.id))
    this.refresh()
    wx.showToast({ title: '全部标记为已读', icon: 'none' })
  },

  noop() {}
})
