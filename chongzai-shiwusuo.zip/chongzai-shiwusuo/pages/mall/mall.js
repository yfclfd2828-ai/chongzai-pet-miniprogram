// 宠崽商城：分类、搜索、商品列表、学员优惠与购物车入口
const mock = require('../../utils/mock.js')
const store = require('../../utils/store.js')

Page({
  data: {
    categories: [],
    activeCat: 'all',
    allProducts: [],
    displayProducts: [],
    keyword: '',
    cartCount: 0
  },

  onLoad() {
    this.setData({
      categories: mock.productCategories,
      allProducts: mock.products,
      displayProducts: mock.products
    })
  },

  onShow() {
    this.setData({ cartCount: store.getCart().length })
  },

  switchCategory(e) {
    const id = e.currentTarget.dataset.id
    const products = id === 'all' ? this.data.allProducts : this.data.allProducts.filter((item) => item.cat === id)
    this.setData({ activeCat: id, displayProducts: products })
  },

  onSearchInput(e) {
    this.setData({ keyword: e.detail.value })
  },

  onSearchConfirm() {
    const keyword = this.data.keyword.trim()
    const list = keyword
      ? this.data.allProducts.filter((item) => item.name.indexOf(keyword) > -1)
      : this.data.allProducts
    this.setData({ activeCat: 'all', displayProducts: list })
  },

  clearSearch() {
    this.setData({ keyword: '', displayProducts: this.data.allProducts, activeCat: 'all' })
  },

  goProduct(e) {
    wx.navigateTo({ url: `/pages/product/product?id=${e.currentTarget.dataset.id}` })
  },

  goCart() {
    wx.navigateTo({ url: '/pages/cart/cart' })
  },

  goCoupons() {
    wx.navigateTo({ url: '/pages/coupons/coupons' })
  },

  goStudentMall() {
    // 学员专区直接展示已过滤出的商品，方便演示专属优惠
    wx.showToast({ title: '学员专属价已展示', icon: 'none' })
  }
})
