// 购物车：勾选、数量调整、删除与去结算
const store = require('../../utils/store.js')

Page({
  data: {
    cart: [],
    allChecked: false,
    selectedCount: 0,
    totalAmount: 0
  },

  onShow() {
    this.refresh()
  },

  refresh() {
    const cart = store.getCart()
    const checked = cart.filter((item) => item.checked)
    const total = checked.reduce((sum, item) => sum + item.price * item.qty, 0)
    this.setData({
      cart,
      allChecked: cart.length > 0 && checked.length === cart.length,
      selectedCount: checked.length,
      totalAmount: Number(total.toFixed(2))
    })
  },

  toggleItem(e) {
    const index = Number(e.currentTarget.dataset.index)
    const checked = !this.data.cart[index].checked
    store.updateCart(index, { checked })
    this.refresh()
  },

  toggleAll() {
    const all = !this.data.allChecked
    this.data.cart.forEach((item, index) => store.updateCart(item.cartIndex, { checked: all }))
    this.refresh()
  },

  minus(e) {
    const index = Number(e.currentTarget.dataset.index)
    const item = this.data.cart[index]
    if (item.qty > 1) store.updateCart(item.cartIndex, { qty: item.qty - 1 })
    this.refresh()
  },

  plus(e) {
    const index = Number(e.currentTarget.dataset.index)
    const item = this.data.cart[index]
    if (item.qty < 99) store.updateCart(item.cartIndex, { qty: item.qty + 1 })
    this.refresh()
  },

  removeItem(e) {
    const index = Number(e.currentTarget.dataset.index)
    wx.showModal({
      title: '移除商品',
      content: '确定不要这件小可爱了吗？',
      confirmText: '移除',
      success: (res) => {
        if (res.confirm) {
          store.removeCartItem(this.data.cart[index].cartIndex)
          this.refresh()
        }
      }
    })
  },

  clearCart() {
    if (!this.data.cart.length) return
    wx.showModal({
      title: '清空购物车',
      content: '将移除购物车里全部 Mock 商品',
      confirmText: '清空',
      success: (res) => {
        if (res.confirm) {
          store.setCart([])
          this.refresh()
        }
      }
    })
  },

  goMall() {
    wx.switchTab({ url: '/pages/mall/mall' })
  },

  goSettle() {
    if (this.data.selectedCount === 0) {
      wx.showToast({ title: '先勾选需要结算的商品', icon: 'none' })
      return
    }
    wx.navigateTo({ url: '/pages/checkout/checkout?from=cart' })
  }
})
