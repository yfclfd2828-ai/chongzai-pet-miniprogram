// 我的养宠日记：展示公开与仅自己可见的日记
const store = require('../../utils/store.js')

Page({
  data: {
    notes: [],
    tab: 'all'
  },

  onShow() {
    this.refresh()
  },

  refresh() {
    const mine = store.getNotes().filter((item) => item.mine)
    this.setData({ notes: mine })
  },

  switchTab(e) {
    this.setData({ tab: e.currentTarget.dataset.tab })
  },

  goDetail(e) {
    wx.navigateTo({ url: `/pages/note-detail/note-detail?id=${e.currentTarget.dataset.id}` })
  },

  goPublish() {
    wx.navigateTo({ url: '/pages/note-edit/note-edit' })
  },

  deleteNote(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '删除日记',
      content: '删除后本地 Mock 日记将不再展示。',
      confirmText: '删除',
      success: (res) => {
        if (res.confirm) {
          store.removeNote(id)
          this.refresh()
        }
      }
    })
  }
})
