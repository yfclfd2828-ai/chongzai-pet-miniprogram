// 训练课程详情：套餐说明、日程、教练与案例推荐
const mock = require('../../utils/mock.js')

Page({
  data: {
    course: null,
    coaches: [],
    cases: [],
    selectedCase: null
  },

  onLoad(options) {
    const id = options.id || 'course-day'
    const course = mock.courses.find((item) => item.id === id) || mock.courses[0]
    this.setData({
      course,
      coaches: mock.coaches,
      cases: mock.cases
    })
    wx.setNavigationBarTitle({ title: course.name })
  },

  bookNow() {
    wx.navigateTo({
      url: `/pages/booking/booking?type=training&courseId=${this.data.course.id}&courseName=${encodeURIComponent(this.data.course.name)}`
    })
  },

  openCoach(e) {
    const coach = this.data.coaches.find((item) => item.id === e.currentTarget.dataset.id)
    if (coach) {
      wx.showModal({
        title: `${coach.name} · ${coach.years}`,
        content: `${coach.intro} 累计服务学员 ${coach.students}+。`,
        showCancel: false,
        confirmText: '知道了'
      })
    }
  },

  openCase(e) {
    const item = this.data.cases.find((one) => one.id === e.currentTarget.dataset.id)
    this.setData({ selectedCase: item })
  },

  closeCase() {
    this.setData({ selectedCase: null })
  },

  goServices() {
    wx.switchTab({ url: '/pages/services/services' })
  },

  noop() {}
})
