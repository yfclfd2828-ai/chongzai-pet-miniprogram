// 我的订单：训练、接送、寄养、美容与商城订单统一管理
const store = require('../../utils/store.js')

Page({
  data: {
    types: [
      { id: 'all', name: '全部', emoji: '🧾' },
      { id: 'training', name: '训练', emoji: '🎓' },
      { id: 'shuttle', name: '接送', emoji: '🚌' },
      { id: 'boarding', name: '寄养', emoji: '🏡' },
      { id: 'grooming', name: '美容', emoji: '🧴' },
      { id: 'mall', name: '商城', emoji: '🛍️' }
    ],
    activeType: 'all',
    allOrders: [],
    displayOrders: [],
    selectedOrder: null,
    cancelable: true
  },

  onLoad(options) {
    this.setData({ activeType: options.type || 'all' })
  },

  onShow() {
    this.refresh()
  },

  refresh() {
    const allOrders = store.getOrders()
    const activeType = this.data.activeType
    const list = activeType === 'all' ? allOrders : allOrders.filter((item) => item.type === activeType)
    this.setData({ allOrders, displayOrders: list })
  },

  switchType(e) {
    const id = e.currentTarget.dataset.id
    this.setData({ activeType: id }, () => this.refresh())
  },

  openDetail(e) {
    const id = e.currentTarget.dataset.id
    const order = this.data.allOrders.find((item) => item.id === id)
    this.setData({
      selectedOrder: order,
      cancelable: order.status === 'paid' || order.status === 'training' || order.status === 'shipped'
    })
  },

  closeDetail() {
    this.setData({ selectedOrder: null })
  },

  cancelOrder() {
    const order = this.data.selectedOrder
    wx.showModal({
      title: '取消订单',
      content: '确认取消这条 Mock 订单吗？',
      confirmText: '取消订单',
      success: (res) => {
        if (!res.confirm) return
        store.updateOrder(order.id, { status: 'cancelled', statusText: '已取消' })
        store.pushMessage({
          type: 'order',
          title: '订单已取消',
          content: `${order.title} 已取消，模拟退款将原路返回。`,
          time: '刚刚'
        })
        this.setData({ selectedOrder: null })
        this.refresh()
      }
    })
  },

  deleteOrder() {
    const order = this.data.selectedOrder
    wx.showModal({
      title: '删除订单',
      content: '删除后仅从 Mock 列表移除，可随时重新下单。',
      confirmText: '删除',
      success: (res) => {
        if (!res.confirm) return
        store.removeOrder(order.id)
        this.setData({ selectedOrder: null })
        this.refresh()
      }
    })
  },

  rebook() {
    const order = this.data.selectedOrder
    const type = order.type === 'mall' ? 'grooming' : order.type
    this.setData({ selectedOrder: null })
    if (order.type === 'mall') {
      wx.switchTab({ url: '/pages/mall/mall' })
      return
    }
    wx.navigateTo({ url: `/pages/booking/booking?type=${type}` })
  },

  goDynamics() {
    const order = this.data.selectedOrder
    this.setData({ selectedOrder: null })
    if (order && order.type === 'training') {
      wx.navigateTo({ url: '/pages/dynamics/dynamics' })
      return
    }
    wx.switchTab({ url: '/pages/services/services' })
  },

  contactTeacher() {
    wx.showModal({
      title: '联系宠崽管家',
      content: '模拟客服：宠崽老师 138-0000-6086',
      showCancel: false,
      confirmText: '好的'
    })
  },

  noop() {},
  goServices() {
    wx.switchTab({ url: '/pages/services/services' })
  },

  goMall() {
    wx.switchTab({ url: '/pages/mall/mall' })
  }
})
