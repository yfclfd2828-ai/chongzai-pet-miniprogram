// 发布养宠日记：支持公开 / 仅自己可见与模拟配图
const store = require('../../utils/store.js')

const TAG_LIST = ['训练日记', '寄养日记', '接送日记', '美容洗护', '养宠好物', '健康记录']
const TONE_BY_TAG = {
  '训练日记': 'peach-bg',
  '寄养日记': 'butter-bg',
  '接送日记': 'mint-bg',
  '美容洗护': 'rose-bg',
  '养宠好物': 'lilac-bg',
  '健康记录': 'peach-bg'
}
const EMOJI_BY_TAG = {
  '训练日记': '🐶',
  '寄养日记': '🏡',
  '接送日记': '🚌',
  '美容洗护': '🧴',
  '养宠好物': '🛍️',
  '健康记录': '💊'
}

Page({
  data: {
    title: '',
    content: '',
    tagList: TAG_LIST,
    activeTag: '训练日记',
    isPublic: true,
    photos: [],
    canAddPhoto: true
  },

  onTitleInput(e) {
    this.setData({ title: e.detail.value })
  },

  onContentInput(e) {
    this.setData({ content: e.detail.value })
  },

  onPrivacyChange(e) {
    this.setData({ isPublic: e.detail.value })
  },

  chooseTag(e) {
    this.setData({ activeTag: e.currentTarget.dataset.tag })
  },

  addPhoto() {
    if (this.data.photos.length >= 3) {
      wx.showToast({ title: '最多添加 3 张 Mock 图片', icon: 'none' })
      return
    }
    const tones = ['peach-bg', 'mint-bg', 'butter-bg', 'lilac-bg', 'rose-bg']
    const emojis = ['🐕', '🐈', '🧸', '🍪', '🦴']
    const seed = this.data.photos.length
    this.setData({
      photos: this.data.photos.concat({ tone: tones[seed], emoji: emojis[seed], label: `Mock 图片 ${seed + 1}` })
    })
  },

  removePhoto(e) {
    const index = e.currentTarget.dataset.index
    const photos = this.data.photos.slice()
    photos.splice(index, 1)
    this.setData({ photos })
  },

  publish() {
    if (!this.data.title.trim()) {
      wx.showToast({ title: '先写一个标题吧', icon: 'none' })
      return
    }
    if (!this.data.content.trim()) {
      wx.showToast({ title: '记录一点今天的心情', icon: 'none' })
      return
    }
    const tag = this.data.activeTag
    const note = store.addNote({
      title: this.data.title.trim(),
      content: this.data.content.trim(),
      public: this.data.isPublic,
      tag,
      tone: TONE_BY_TAG[tag],
      emoji: EMOJI_BY_TAG[tag],
      photos: this.data.photos
    })
    wx.showToast({ title: this.data.isPublic ? '发布成功' : '已保存为仅自己可见', icon: 'success' })
    setTimeout(() => {
      wx.redirectTo({ url: `/pages/note-detail/note-detail?id=${note.id}` })
    }, 600)
  }
})
