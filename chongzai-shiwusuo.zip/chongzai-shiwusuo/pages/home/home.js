// 首页：轮播、快捷入口、课程推荐、爆款与热门笔记
const store = require('../../utils/store.js')

Page({
  data: {
    banners: [],
    notices: [],
    quickEntries: [],
    courses: [],
    products: [],
    notes: [],
    noticeIndex: 0,
    cartCount: 0
  },

  onLoad() {
    // 引用全局 Mock 数据
    this.setData({
      banners: require('../../utils/mock.js').banners,
      notices: require('../../utils/mock.js').notices,
      quickEntries: require('../../utils/mock.js').quickEntries,
      moments: require('../../utils/mock.js').moments.slice(0, 3)
    })
  },

  onShow() {
    const mock = require('../../utils/mock.js')
    const notes = store.getNotes()
    this.setData({
      courses: mock.courses.slice(0, 2),
      products: mock.products.slice(0, 4),
      notes: notes.filter((item) => item.public).slice(0, 3),
      cartCount: store.getCart().length
    })
  },

  goQuick(e) {
    const id = e.currentTarget.dataset.id
    if (id === 'training') {
      wx.switchTab({ url: '/pages/services/services' })
      return
    }
    if (id === 'mall') {
      wx.switchTab({ url: '/pages/mall/mall' })
      return
    }
    if (id === 'community') {
      wx.switchTab({ url: '/pages/community/community' })
      return
    }
    wx.navigateTo({ url: `/pages/booking/booking?type=${id}` })
  },

  goBanner() {
    wx.switchTab({ url: '/pages/services/services' })
  },

  goServices() {
    wx.switchTab({ url: '/pages/services/services' })
  },

  goMall() {
    wx.switchTab({ url: '/pages/mall/mall' })
  },

  goCommunity() {
    wx.switchTab({ url: '/pages/community/community' })
  },

  goCart() {
    wx.navigateTo({ url: '/pages/cart/cart' })
  },

  goDynamics() {
    wx.navigateTo({ url: '/pages/dynamics/dynamics' })
  },

  goCourse(e) {
    wx.navigateTo({ url: `/pages/course/course?id=${e.currentTarget.dataset.id}` })
  },

  goProduct(e) {
    wx.navigateTo({ url: `/pages/product/product?id=${e.currentTarget.dataset.id}` })
  },

  goNote(e) {
    wx.navigateTo({ url: `/pages/note-detail/note-detail?id=${e.currentTarget.dataset.id}` })
  },

  showAllProducts() {
    wx.switchTab({ url: '/pages/mall/mall' })
  },

  onNoticeTap() {
    const next = (this.data.noticeIndex + 1) % this.data.notices.length
    this.setData({ noticeIndex: next })
  }
})
