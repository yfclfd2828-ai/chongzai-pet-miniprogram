// 预约表单页：训练 / 接送 / 寄养 / 美容洗护共用一个可复用页面
const mock = require('../../utils/mock.js')
const store = require('../../utils/store.js')

const TYPE_NAMES = {
  training: '训练托管',
  shuttle: '接送预约',
  boarding: '寄养预约',
  grooming: '美容洗护'
}

Page({
  data: {
    type: 'training',
    service: null,
    pets: [],
    petNames: [],
    petIndex: 0,
    courses: [],
    courseIndex: 0,
    courseDays: 7,
    dayOptions: [3, 7, 14, 30],
    dayIndex: 1,
    shuttleCount: 3,
    shuttleCounts: [1, 3, 5, 10],
    shuttleIndex: 1,
    nights: 1,
    nightOptions: [1, 2, 3, 7],
    timeOptions: ['09:00-10:00', '10:30-11:30', '14:00-15:00', '15:30-16:30', '17:00-18:00'],
    timeIndex: 0,
    date: '2026-09-12',
    address: '',
    contactName: '栗子妈妈',
    contactPhone: '13800006086',
    memo: '',
    groomingItems: [
      { name: '基础洗护', extra: 0, selected: true },
      { name: '剪指甲', extra: 20, selected: true },
      { name: '耳道清洁', extra: 15, selected: false },
      { name: '可爱造型', extra: 60, selected: false }
    ],
    amount: 0,
    successOrder: null
  },

  onLoad(options) {
    const type = options.type || 'training'
    const service = type === 'training'
      ? { emoji: '🎓', tone: 'peach-bg', title: '预约训练课程', desc: '训练托管与行为课程均在这里预约，老师会电话确认。' }
      : (mock.lifeServices.find((item) => item.type === type) || mock.lifeServices[0])
    const courses = mock.courses
    const pets = store.getPets()
    const petNames = pets.map((item) => item.name)
    const defaultCourse = options.courseId || 'course-day'
    const courseIndex = Math.max(0, courses.findIndex((item) => item.id === defaultCourse))
    const courseName = options.courseName ? decodeURIComponent(options.courseName) : ''
    this.setData({
      type,
      service,
      courses,
      pets,
      petNames,
      courseIndex,
      date: this.nextDate(2),
      address: type === 'shuttle' ? '栗子路 88 号 3 栋' : '',
      memo: courseName ? `想约 ${courseName}` : ''
    }, () => this.recalc())
    wx.setNavigationBarTitle({ title: type === 'training' ? '预约训练' : service.title })
  },

  nextDate(days) {
    const d = new Date()
    d.setDate(d.getDate() + days)
    const pad = (n) => String(n).padStart(2, '0')
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
  },

  onPetChange(e) {
    this.setData({ petIndex: Number(e.detail.value) })
  },

  onCourseChange(e) {
    this.setData({ courseIndex: Number(e.detail.value) }, () => this.recalc())
  },

  onDateChange(e) {
    this.setData({ date: e.detail.value })
  },

  onTimeChange(e) {
    this.setData({ timeIndex: Number(e.detail.value) })
  },

  onDayChange(e) {
    const index = Number(e.detail.value)
    this.setData({ dayIndex: index, courseDays: this.data.dayOptions[index] }, () => this.recalc())
  },

  onCountChange(e) {
    const index = Number(e.detail.value)
    this.setData({ shuttleIndex: index, shuttleCount: this.data.shuttleCounts[index] }, () => this.recalc())
  },

  onNightChange(e) {
    this.setData({ nights: Number(e.detail.value) }, () => this.recalc())
  },

  onAddressInput(e) {
    this.setData({ address: e.detail.value })
  },

  onContactInput(e) {
    this.setData({ contactName: e.detail.value })
  },

  onPhoneInput(e) {
    this.setData({ contactPhone: e.detail.value })
  },

  onMemoInput(e) {
    this.setData({ memo: e.detail.value })
  },

  toggleGrooming(e) {
    const index = e.currentTarget.dataset.index
    const key = `groomingItems[${index}].selected`
    this.setData({ [key]: !this.data.groomingItems[index].selected }, () => this.recalc())
  },

  recalc() {
    const type = this.data.type
    let amount = 0
    let title = ''
    if (type === 'training') {
      const course = this.data.courses[this.data.courseIndex] || this.data.courses[0]
      amount = course.price * this.data.courseDays
      title = `${course.name} · ${this.data.courseDays} 天`
    } else if (type === 'shuttle') {
      amount = this.data.service.price * this.data.shuttleCount
      title = `宠物接送 · ${this.data.shuttleCount} 次`
    } else if (type === 'boarding') {
      amount = this.data.service.price * this.data.nights
      title = `短期寄养 · ${this.data.nights} 晚`
    } else {
      const base = this.data.groomingItems.find((item) => item.name === '基础洗护')
      amount = (base && base.selected ? 128 : 0) + this.data.groomingItems.filter((item) => item.selected && item.extra > 0)
        .reduce((sum, item) => sum + item.extra, 0)
      const selectedNames = this.data.groomingItems.filter((item) => item.selected).map((item) => item.name)
      title = selectedNames.length ? selectedNames.join(' + ') : '美容洗护'
    }
    this.setData({ amount, orderTitle: title })
  },

  submit() {
    const type = this.data.type
    if (!this.data.contactName || !this.data.contactPhone) {
      wx.showToast({ title: '请填写联系人信息', icon: 'none' })
      return
    }
    if (type === 'shuttle' && !this.data.address) {
      wx.showToast({ title: '请填写接送地址', icon: 'none' })
      return
    }
    if (type === 'grooming' && !this.data.groomingItems.some((item) => item.selected)) {
      wx.showToast({ title: '请选择洗护项目', icon: 'none' })
      return
    }
    const pet = this.data.pets[this.data.petIndex] || { name: '毛孩子' }
    const time = this.data.timeOptions[this.data.timeIndex]
    const course = type === 'training' ? (this.data.courses[this.data.courseIndex] || this.data.courses[0]) : null
    const start = `${this.data.date} ${type === 'boarding' ? '入住当日 14:00' : time}`
    const descMap = {
      training: `课程：${this.data.orderTitle}；老师会在到校前电话确认。`,
      shuttle: `接送 ${this.data.shuttleCount} 次；地址：${this.data.address}。`,
      boarding: `寄养 ${this.data.nights} 晚；含每日遛放和照片反馈。`,
      grooming: `项目：${this.data.orderTitle}；建议提前 10 分钟到店。`
    }
    const statusMap = {
      training: '待入校',
      shuttle: '待确认',
      boarding: '待入住',
      grooming: '待到店'
    }
    const order = store.createOrder({
      type,
      typeName: TYPE_NAMES[type],
      title: this.data.orderTitle,
      pet: pet.name,
      status: 'paid',
      statusText: statusMap[type],
      amount: this.data.amount,
      date: this.data.date,
      start,
      end: type === 'boarding' ? `${this.nextDate(Number(this.data.nights))} 12:00` : '',
      coach: type === 'training' && course ? '米粒老师' : '宠崽管家',
      place: type === 'shuttle' ? this.data.address : '宠崽事务所 · 朝阳校区',
      desc: descMap[type],
      emoji: (course || this.data.service).emoji,
      contactName: this.data.contactName,
      contactPhone: this.data.contactPhone,
      memo: this.data.memo
    })
    store.pushMessage({
      type: 'order',
      title: `${TYPE_NAMES[type]}预约已提交`,
      content: `${order.title}（${order.pet}）已生成模拟订单 ${order.id}。`,
      time: '刚刚'
    })
    this.setData({ successOrder: order })
  },

  closeSuccess() {
    this.setData({ successOrder: null })
  },

  goOrders() {
    const order = this.data.successOrder
    this.setData({ successOrder: null })
    wx.redirectTo({ url: `/pages/orders/orders?type=${order.type}` })
  },

  keepBooking() {
    this.setData({ successOrder: null })
  }
})
