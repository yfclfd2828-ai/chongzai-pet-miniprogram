// 服务页：训练套餐、教练、案例、接送/寄养/美容预约入口
const mock = require('../../utils/mock.js')

Page({
  data: {
    courses: [],
    lifeServices: [],
    coaches: [],
    cases: [],
    moments: [],
    selectedCoach: null,
    selectedCase: null,
    serviceModal: false,
    selectedService: null
  },

  onLoad() {
    this.setData({
      courses: mock.courses,
      lifeServices: mock.lifeServices,
      coaches: mock.coaches,
      cases: mock.cases,
      moments: mock.moments.slice(0, 3)
    })
  },

  goCourse(e) {
    wx.navigateTo({ url: `/pages/course/course?id=${e.currentTarget.dataset.id}` })
  },

  goDynamics() {
    wx.navigateTo({ url: '/pages/dynamics/dynamics' })
  },

  openCoach(e) {
    const id = e.currentTarget.dataset.id
    const coach = this.data.coaches.find((item) => item.id === id)
    this.setData({ selectedCoach: coach })
  },

  closeCoach() {
    this.setData({ selectedCoach: null })
  },

  openCase(e) {
    const id = e.currentTarget.dataset.id
    const item = this.data.cases.find((one) => one.id === id)
    this.setData({ selectedCase: item })
  },

  closeCase() {
    this.setData({ selectedCase: null })
  },

  openService(e) {
    const type = e.currentTarget.dataset.type
    const item = this.data.lifeServices.find((one) => one.type === type)
    this.setData({ selectedService: item, serviceModal: true })
  },

  closeService() {
    this.setData({ serviceModal: false, selectedService: null })
  },

  bookFromService() {
    const type = this.data.selectedService.type
    this.setData({ serviceModal: false, selectedService: null })
    wx.navigateTo({ url: `/pages/booking/booking?type=${type}` })
  },

  bookNow(e) {
    wx.navigateTo({ url: `/pages/booking/booking?type=${e.currentTarget.dataset.type}` })
  },

  noop() {},

  goRules() {
    wx.navigateTo({ url: '/pages/help/help' })
  }
})
