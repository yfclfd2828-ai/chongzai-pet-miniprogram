// 宠崽在校动态：照片占位、短视频占位与老师训练评语
const mock = require('../../utils/mock.js')

Page({
  data: {
    pets: [
      { id: 'all', name: '全部', emoji: '🐾' },
      { id: 'pet-1', name: '布丁', emoji: '🐶' },
      { id: 'pet-2', name: '雪球', emoji: '🐱' }
    ],
    activePet: 'all',
    allMoments: [],
    displayMoments: [],
    selectedMoment: null
  },

  onLoad() {
    this.setData({ allMoments: mock.moments, displayMoments: mock.moments })
  },

  switchPet(e) {
    const id = e.currentTarget.dataset.id
    const list = id === 'all' ? this.data.allMoments : this.data.allMoments.filter((item) => {
      return (item.pet === '布丁' && id === 'pet-1') || (item.pet === '雪球' && id === 'pet-2')
    })
    this.setData({ activePet: id, displayMoments: list })
  },

  openMoment(e) {
    const item = this.data.allMoments.find((one) => one.id === e.currentTarget.dataset.id)
    this.setData({ selectedMoment: item })
  },

  closeMoment() {
    this.setData({ selectedMoment: null })
  },

  playVideo() {
    wx.showToast({ title: '模拟播放短视频中', icon: 'none' })
  },

  sendComment() {
    wx.showToast({ title: '评语已转达老师', icon: 'none' })
  },

  goBooking() {
    wx.navigateTo({ url: '/pages/booking/booking?type=training' })
  },

  noop() {}
})
