// 养宠问答：浏览问答、点赞与发起新提问
const mock = require('../../utils/mock.js')
const store = require('../../utils/store.js')

Page({
  data: {
    qaList: [],
    showAsk: false,
    askText: '',
    hotList: []
  },

  onLoad() {
    const qaList = mock.qaList
    const hotList = mock.qaList.slice(0, 2)
    this.setData({ qaList, hotList })
  },

  openAsk() {
    this.setData({ showAsk: true })
  },

  closeAsk() {
    this.setData({ showAsk: false, askText: '' })
  },

  onAskInput(e) {
    this.setData({ askText: e.detail.value })
  },

  submitAsk() {
    const text = this.data.askText.trim()
    if (!text) {
      wx.showToast({ title: '先写下你的问题', icon: 'none' })
      return
    }
    this.setData({
      showAsk: false,
      askText: '',
      qaList: [{
        id: store.makeId('q-'),
        question: text,
        answer: '问题已发布，宠崽老师与养宠家长会尽快回复～（Mock 演示）',
        category: '等待回复',
        votes: 1,
        time: '刚刚'
      }, ...this.data.qaList]
    })
    store.pushMessage({
      type: 'school',
      title: '问题发布成功',
      content: `“${text.slice(0, 20)}”已发布，收到回复会通知你。`,
      time: '刚刚'
    })
  },

  vote(e) {
    const id = e.currentTarget.dataset.id
    const qaList = this.data.qaList.map((item) => {
      if (item.id !== id) return item
      return { ...item, votes: item.votes + 1 }
    })
    this.setData({ qaList })
  },

  goCommunity() {
    wx.switchTab({ url: '/pages/community/community' })
  },

  goHelp() {
    wx.navigateTo({ url: '/pages/help/help' })
  },

  noop() {}
})
