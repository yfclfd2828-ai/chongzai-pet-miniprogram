// 帮助中心：入校须知、接送规则、服务规则与常见问题
const mock = require('../../utils/mock.js')

Page({
  data: {
    faqs: [],
    openIndex: 0,
    rules: [],
    ruleGroups: []
  },

  onLoad() {
    const faqs = mock.helpFaqs.map((item, index) => ({ ...item, open: index === 0 }))
    this.setData({
      faqs,
      rules: mock.serviceRules,
      ruleGroups: [
        { type: 'shuttle', title: '接送规则', emoji: '🚌', tone: 'mint-bg' },
        { type: 'boarding', title: '寄养规则', emoji: '🏡', tone: 'butter-bg' },
        { type: 'grooming', title: '洗护须知', emoji: '🧴', tone: 'lilac-bg' }
      ]
    })
  },

  toggleFaq(e) {
    const index = Number(e.currentTarget.dataset.index)
    const key = `faqs[${index}].open`
    this.setData({ [key]: !this.data.faqs[index].open })
  },

  toggleRule(e) {
    const index = Number(e.currentTarget.dataset.index)
    const key = `rules[${index}].open`
    this.setData({ [key]: !this.data.rules[index].open })
  },

  goBooking(e) {
    const type = e.currentTarget.dataset.type
    wx.navigateTo({ url: `/pages/booking/booking?type=${type}` })
  },

  contact() {
    wx.showModal({
      title: '联系宠崽老师',
      content: '模拟客服电话：138-0000-6086\n服务时间：09:00-21:00',
      showCancel: false,
      confirmText: '知道了'
    })
  }
})
