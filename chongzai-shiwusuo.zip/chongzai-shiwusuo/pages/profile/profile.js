// 个人中心：订单入口、档案、日记、优惠券、消息与帮助
const store = require('../../utils/store.js')

Page({
  data: {
    user: {},
    stats: {
      petCount: 0,
      noteCount: 0,
      orderCount: 0,
      couponCount: 0
    },
    unreadCount: 0,
    activeOrder: null,
    orderTypes: [
      { type: 'all', label: '全部订单', icon: '🧾' },
      { type: 'training', label: '训练托管', icon: '🎓' },
      { type: 'shuttle', label: '接送', icon: '🚌' },
      { type: 'boarding', label: '寄养', icon: '🏡' },
      { type: 'grooming', label: '美容', icon: '🧴' },
      { type: 'mall', label: '商城', icon: '🛍️' }
    ]
  },

  onLoad() {
    const app = getApp()
    this.setData({ user: app.globalData.user })
  },

  onShow() {
    const stats = store.getProfileStats()
    const unread = store.getMessages().filter((item) => !item.read).length
    this.setData({ stats, unreadCount: unread })
  },

  goOrders(e) {
    const type = e.currentTarget.dataset.type || 'all'
    wx.navigateTo({ url: `/pages/orders/orders?type=${type}` })
  },

  goPet() {
    wx.navigateTo({ url: '/pages/pet/pet' })
  },

  goMyNotes() {
    wx.navigateTo({ url: '/pages/my-notes/my-notes' })
  },

  goCoupons() {
    wx.navigateTo({ url: '/pages/coupons/coupons' })
  },

  goMessages() {
    wx.navigateTo({ url: '/pages/messages/messages' })
  },

  goHelp() {
    wx.navigateTo({ url: '/pages/help/help' })
  },

  goSchool() {
    wx.switchTab({ url: '/pages/services/services' })
  },

  contactService() {
    wx.showModal({
      title: '联系客服',
      content: '模拟客服：宠崽老师 138-0000-6086\n服务时间 09:00-21:00',
      showCancel: false,
      confirmText: '好的'
    })
  },

  logout() {
    wx.showModal({
      title: '退出登录',
      content: '这是 Mock 演示账号，退出后仍可重新进入查看。',
      confirmText: '退出',
      success: (res) => {
        if (res.confirm) {
          wx.showToast({ title: '已退出演示账号', icon: 'none' })
        }
      }
    })
  }
})
