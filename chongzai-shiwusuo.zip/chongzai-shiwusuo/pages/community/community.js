// 养宠社区广场：笔记互动、问答入口与线下活动报名
const store = require('../../utils/store.js')

Page({
  data: {
    activeTab: 0,
    tags: ['全部', '训练日记', '寄养日记', '洗护日记', '养宠好物'],
    activeTag: '全部',
    allNotes: [],
    displayNotes: [],
    qaList: [],
    activities: []
  },

  onLoad() {
    const mock = require('../../utils/mock.js')
    this.setData({ qaList: mock.qaList, activities: mock.activities })
  },

  onShow() {
    this.refreshNotes()
  },

  refreshNotes() {
    const allNotes = store.getNotes().filter((item) => item.public)
    this.setData({ allNotes, displayNotes: allNotes })
  },

  switchTab(e) {
    this.setData({ activeTab: Number(e.currentTarget.dataset.tab) })
  },

  switchTag(e) {
    const tag = e.currentTarget.dataset.tag
    const notes = tag === '全部' ? this.data.allNotes : this.data.allNotes.filter((item) => item.tag === tag)
    this.setData({ activeTag: tag, displayNotes: notes })
  },

  goNote(e) {
    wx.navigateTo({ url: `/pages/note-detail/note-detail?id=${e.currentTarget.dataset.id}` })
  },

  goQA() {
    wx.navigateTo({ url: '/pages/qa/qa' })
  },

  goActivity() {
    wx.navigateTo({ url: '/pages/activity/activity' })
  },

  goActivityItem(e) {
    wx.navigateTo({ url: `/pages/activity/activity?id=${e.currentTarget.dataset.id}` })
  },

  publishNote() {
    wx.navigateTo({ url: '/pages/note-edit/note-edit' })
  },

  toggleLike(e) {
    store.toggleNoteField(e.currentTarget.dataset.id, 'liked')
    this.refreshNotes()
  },

  toggleCollect(e) {
    store.toggleNoteField(e.currentTarget.dataset.id, 'collected')
    this.refreshNotes()
  },

  goMyNotes() {
    wx.navigateTo({ url: '/pages/my-notes/my-notes' })
  },

  followAuthor() {
    wx.showToast({ title: '已关注该养宠家长', icon: 'none' })
  }
})
