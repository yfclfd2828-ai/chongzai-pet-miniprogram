// 线下活动：浏览、报名与取消报名
const mock = require('../../utils/mock.js')
const store = require('../../utils/store.js')

Page({
  data: {
    activities: [],
    signups: [],
    selectedActivity: null,
    successId: null
  },

  onLoad(options) {
    this.setData({ activities: mock.activities })
    if (options.id) {
      const target = mock.activities.find((item) => item.id === options.id)
      if (target) this.setData({ selectedActivity: target })
    }
  },

  onShow() {
    this.setData({ signups: store.getActivitySignups() })
  },

  openDetail(e) {
    const item = this.data.activities.find((one) => one.id === e.currentTarget.dataset.id)
    this.setData({ selectedActivity: item })
  },

  closeDetail() {
    this.setData({ selectedActivity: null })
  },

  signUp() {
    const activity = this.data.selectedActivity
    store.signActivity(activity.id)
    this.setData({
      successId: activity.id,
      signups: store.getActivitySignups()
    })
  },

  closeSuccess() {
    this.setData({ successId: null, selectedActivity: null })
  },

  cancelSignup() {
    const activity = this.data.selectedActivity
    wx.showModal({
      title: '取消报名',
      content: `确定取消 ${activity.name} 的报名吗？`,
      confirmText: '取消报名',
      success: (res) => {
        if (!res.confirm) return
        store.cancelActivity(activity.id)
        this.setData({ signups: store.getActivitySignups() })
        wx.showToast({ title: '已取消报名', icon: 'none' })
      }
    })
  },

  goCommunity() {
    wx.switchTab({ url: '/pages/community/community' })
  },

  noop() {}
})
