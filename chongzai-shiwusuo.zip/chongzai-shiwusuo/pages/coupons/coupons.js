// 优惠券中心：可用、已用、过期与模拟领取
const store = require('../../utils/store.js')
const mock = require('../../utils/mock.js')

Page({
  data: {
    tabs: [
      { id: 'available', name: '可用' },
      { id: 'used', name: '已使用' },
      { id: 'expired', name: '已过期' }
    ],
    activeTab: 'available',
    allCoupons: [],
    displayCoupons: []
  },

  onShow() {
    this.refresh()
  },

  refresh() {
    const allCoupons = store.getCoupons()
    const list = allCoupons.filter((item) => item.status === this.data.activeTab)
    this.setData({ allCoupons, displayCoupons: list })
  },

  switchTab(e) {
    this.setData({ activeTab: e.currentTarget.dataset.id }, () => this.refresh())
  },

  receiveCoupon() {
    const coupons = store.getCoupons()
    coupons.push({
      id: store.makeId('coupon-'),
      title: '新学员见面券',
      condition: '满 300 元可用',
      price: 50,
      kind: 'training',
      end: '2026-10-31',
      status: 'available',
      icon: '🎁'
    })
    store.setCoupons(coupons)
    this.refresh()
    wx.showToast({ title: '已领取 50 元券', icon: 'success' })
  },

  useCoupon(e) {
    const kind = e.currentTarget.dataset.kind
    if (kind === 'mall') {
      wx.switchTab({ url: '/pages/mall/mall' })
      return
    }
    if (kind === 'training') {
      wx.switchTab({ url: '/pages/services/services' })
      return
    }
    const type = kind === 'shuttle' ? 'shuttle' : kind === 'grooming' ? 'grooming' : 'boarding'
    wx.navigateTo({ url: `/pages/booking/booking?type=${type}` })
  },

  goMall() {
    wx.switchTab({ url: '/pages/mall/mall' })
  }
})
