// 笔记详情：点赞、收藏、评论与作者关注
const store = require('../../utils/store.js')

Page({
  data: {
    note: null,
    commentText: '',
    comments: [],
    related: [],
    focusInput: false
  },

  onLoad(options) {
    this.noteId = options.id
    this.localComments = []
    this.loadNote()
  },

  onShow() {
    if (this.noteId) this.loadNote()
  },

  loadNote() {
    const all = store.getNotes()
    let note = all.find((item) => item.id === this.noteId)
    if (!note) note = all[0]
    if (!note) {
      wx.showToast({ title: '笔记不存在', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 400)
      return
    }
    this.noteId = note.id
    const baseComments = [
      { name: '雪球姐姐', emoji: '🐱', text: '太可爱了！看到这条我也有动力开始练习了。', time: '10 分钟前' },
      { name: '米粒老师', emoji: '🐕', text: '布丁今天表现很棒，回家也要坚持小练习哦。', time: '30 分钟前' }
    ]
    const comments = this.localComments && this.localComments.length ? this.localComments : baseComments
    const related = all.filter((item) => item.id !== note.id && item.public).slice(0, 2)
    this.setData({ note, comments, related })
  },

  toggleLike() {
    store.toggleNoteField(this.noteId, 'liked')
    this.loadNote()
  },

  toggleCollect() {
    store.toggleNoteField(this.noteId, 'collected')
    this.loadNote()
  },

  onCommentInput(e) {
    this.setData({ commentText: e.detail.value })
  },

  focusComment() {
    this.setData({ focusInput: true })
  },

  sendComment() {
    const text = this.data.commentText.trim()
    if (!text) {
      wx.showToast({ title: '先写点什么吧', icon: 'none' })
      return
    }
    store.addCommentToNote(this.noteId)
    const updated = store.getNotes().find((item) => item.id === this.noteId)
    this.localComments = this.data.comments.concat({
      name: '栗子妈妈',
      emoji: '👩',
      text,
      time: '刚刚'
    })
    this.setData({
      comments: this.localComments,
      commentText: '',
      'note.comments': updated ? updated.comments : this.data.note.comments
    })
  },

  shareNote() {
    wx.showToast({ title: '模拟分享成功', icon: 'none' })
  },

  followAuthor() {
    wx.showToast({ title: '已关注该养宠家长', icon: 'none' })
  },

  goRelated(e) {
    const id = e.currentTarget.dataset.id
    this.noteId = id
    this.loadNote()
    wx.pageScrollTo({ scrollTop: 0, duration: 0 })
  },

  goEdit() {
    wx.navigateTo({ url: '/pages/note-edit/note-edit' })
  }
})
